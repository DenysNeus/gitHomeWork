
public class ReviewClass02 {

	public static void main(String[] args) {

		int num = 10;
		int num1 = 20;
		System.out.println(num / num1);
		System.out.println(num % num1);
		System.out.println("************************");
		double num2 = 10;
		double num3 = 20;
		System.out.println(num2 / num3);
		System.out.println(num2 % num3);
		System.out.println("************************");
		System.out.println(num3 / num2);
		System.out.println(num3 % num2);

		num2 = -10;
		num3 = -20;
		System.out.println(num2 / num3);
		System.out.println(num2 % num3);
		System.out.println(num3 % num2);
		System.out.println("************************");
		num2 = 10.5;
		num3 = 5.5;
		System.out.println(num2 % num3);

	}

}
