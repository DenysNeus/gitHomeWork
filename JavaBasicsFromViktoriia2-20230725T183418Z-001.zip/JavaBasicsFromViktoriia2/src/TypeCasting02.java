
public class TypeCasting02 {

	public static void main(String[] args) {

		byte num = (byte) 129;
		System.out.println(num);
		short num1 = 115;
		//byte num2 = (byte) num1;
		System.out.println(num1);

		System.out.println((int) 12.5);
		System.out.println((double) 12);
	}

}
