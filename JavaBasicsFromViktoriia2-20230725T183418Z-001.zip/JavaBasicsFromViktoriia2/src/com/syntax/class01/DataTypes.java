package com.syntax.class01;

public class DataTypes {

	public static void main(String[] args) {

		// storing whole numbers
		byte box1 = 2; // range from -128 till 127

		short box2 = 36;// range from 32768 till 32767

		int box3 = 27489;// most popular data type to use for whole numbers

		long box4 = 1000000000748993L; // use big L or small l in the end if number is to big

		// representing and storing decimal numbers
		float box5 = 1.99f;// use a big or small F in the end
		double box6 = 234.85;

		// representing and storing single character
		char a = 'V';
		char b = '*';

		// representing and storing boolean values (yes or no)
		boolean hungry = true;// yes
		boolean tired = false;// no

		System.out.println(box1);
		

	}

}
