package com.syntax.class01;

public class HelloWorld {

	public static void main(String[] args) {
		
		System.out.println("Hello Vika :) ");
		System.out.println("Welcome back");
		System.out.println("I miss you so much");
	
	/*
	 * 
	 */
	
	
	}

}
