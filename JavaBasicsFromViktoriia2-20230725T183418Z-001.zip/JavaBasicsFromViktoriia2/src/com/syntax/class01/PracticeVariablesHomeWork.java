package com.syntax.class01;

public class PracticeVariablesHomeWork {

	public static void main(String[] args) {

		byte a = 127;
		short b = 4562;
		int c = 6583932;
		long d = 25474822193956l;
		float f = 3.63f;
		double double1 = 5673.74628;
		boolean happy = true;
		boolean sad = false;

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(f);
		System.out.println(double1);
		System.out.println(happy);
		System.out.println(sad);

	}

}
