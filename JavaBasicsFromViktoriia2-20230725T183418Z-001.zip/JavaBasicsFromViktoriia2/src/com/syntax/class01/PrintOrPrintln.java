package com.syntax.class01;

public class PrintOrPrintln {

	public static void main(String[] args) {

		/*
		 * println----> prints statement and creates new line
		 * 
		 * 
		 * print----> just prints a statement and leaves cursor on the same line
		 *        (no new line is added)
		 */
	System.out.print("This is print command");
	System.out.println("This is println command");
	System.out.println("Hello");
	
		
	}

}
