package com.syntax.class01;

public class SyntaxProgrammer {

	public static void main(String[] args) {

		/*
		 * shortcut to format your code 
		 * 
		 * mac: cmd+shift+f
		 * 
		 * windows: ctrl+shift+f
		 */

		System.out.print("I am a Java Programmer.");
		System.out.println(" I study at Syntax");
		System.out.println("I love Java");
		System.out.println("!!!");
	}

}
