package com.syntax.class01;

public class TheProgrammer {

	public static void main(String[] args) {

	//This is my second Java Program
		
		System.out.println("I am a cool Java Programmer!");
	System.out.println(2023);
	System.out.println("In "+2024+ " year i will find my great job!");
	
	}

}