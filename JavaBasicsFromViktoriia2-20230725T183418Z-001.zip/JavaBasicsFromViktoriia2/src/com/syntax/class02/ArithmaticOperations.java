package com.syntax.class02;

public class ArithmaticOperations {

	public static void main(String[] args) {

		int number1 = 10;
		int number2 = 20;
		System.out.println(number1 + number2);
		System.out.println(number1 - number2);
		System.out.println(number2 - number1);
		System.out.println(number1 * number2);
		System.out.println(number1 / number2);
		System.out.println("***************************************");
		double num1 = 10;
		double num2 = 20;
		System.out.println(num1 + num2);
		System.out.println(num1 - num2);
		System.out.println(num1 * num2);
		System.out.println(num1 / num2);
		System.out.println("***************************************");
		System.out.println(number1 / num2);

		boolean var1 = true;
		boolean var2 = false;
		// System.out.println(var1+var2); not allowed on booleans
		System.out.println("***************************************");

		char char1 = '1';
		char char2 = '2';
		System.out.println(char1 + char2);
		System.out.println(char1 - char2);
		System.out.println(char1 * char2);
		System.out.println(char1 / char2);

		System.out.println("***************************************");

		String str1 = "Hi";
		String str2 = "Bye";
		System.out.println(str1 + str2);
		// System.out.println(str1-str2); not allowed
		// System.out.println(str1*str2); not allowed
		// System.out.println(str1/str2); not allowed

	}

}
