package com.syntax.class02;

public class Important {

	public static void main(String[] args) {

		System.out.println(10+10+"Hello");
		System.out.println("Hello"+(10+10));
	}

}
