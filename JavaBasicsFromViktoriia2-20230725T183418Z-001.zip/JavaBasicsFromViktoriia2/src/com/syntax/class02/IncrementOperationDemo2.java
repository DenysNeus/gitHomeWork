package com.syntax.class02;

public class IncrementOperationDemo2 {

	public static void main(String[] args) {

		int num = 10;
		num = num + num + num + num;//(10+10+10+10=40) num=40;
		System.out.println(num);
		num = num + 10 + 18 + 47;//(40+10+18+47=115)
		System.out.println(num);
		System.out.println("**************");
		num = 10;
		num = num - num;
		System.out.println(num);   //(10-10=0)
		num = 10;
		num = num * num;   
		System.out.println(num); //(10*10=100)
		num = 10;
		num = num / num; //1
		System.out.println(num);//(10/10=1)
		
		System.out.println("*****************");
		
		
num=10;
num--;
System.out.println(num);
//num**; not supported
//num//; not pissible
//num%%; not allowed

		
		
		
	}

}
