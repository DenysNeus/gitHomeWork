package com.syntax.class02;

public class IncrementOperatorDemo1 {

	public static void main(String[] args) {

		int number = 10;
		number = number + 1;
		number = number + number;
		System.out.println(number);

		System.out.println("**********************");
		number++; // increments the value by one -----> number=number+1;
		System.out.println(number);

		System.out.println("**********************");
		number = 10;
		number++;
		System.out.println(number);

	}

}
