package com.syntax.class02;

public class ModOperatorDemo {

	public static void main(String[] args) {

		int number1 = 20;
		int number2 = 3;
		System.out.println(number1 % number2);

		int number3 = 79;
		int number4 = 25;
		System.out.println(number3 % number4);
		System.out.println(2 % 25);// if i am taking mod of a smaller number with a bigger number I will always get
									// smaller number as a answer

		System.out.println("*******************");
		double num01 = 38;
		double num02 = 4;
		System.out.println(num01 % num02);
		System.out.println(num01 / num02);
		
		

	}

}
