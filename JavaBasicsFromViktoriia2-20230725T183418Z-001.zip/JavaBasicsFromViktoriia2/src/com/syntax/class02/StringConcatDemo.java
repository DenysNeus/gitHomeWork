package com.syntax.class02;

public class StringConcatDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	double price=12.34;
	String fruit="banana";
	char symbol='$';
	System.out.println("The price of "+fruit+" is "+price+symbol);
	
		
	}

}
