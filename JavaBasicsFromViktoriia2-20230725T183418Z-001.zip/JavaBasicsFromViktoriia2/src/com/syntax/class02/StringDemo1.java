package com.syntax.class02;

public class StringDemo1 {

	public static void main(String[] args) {

		String name = "Viktoriia";
		System.out.println(name);
		String adress="Lunina2 street";
		System.out.println(name+adress);
		int age=30;
		System.out.println(age+name);
		boolean happy=true;
		System.out.println(name+happy+age);
		System.out.println("My name is "+name+" My age is  "+age+" My adress is "+adress);

	}

}
