package com.syntax.class02;

public class Task1 {

	public static void main(String[] args) {
		double num = 246.84;
		double num1 = 3378.945;

		System.out.println("The add of 2 numbers " + num + " and " + num1 + " is equal to " + (num + num1));
		System.out.println("The subtract of 2 numbers " + num + " and " + num1 + " is equal to " + (num - num1));
		System.out.println("The multiply of 2 numbers " + num + " and " + num1 + " is equal to " + (num * num1));
		System.out.println("The divide of 2 numbers " + num + " and " + num1 + " is equal to " + (num / num1));

	}

}
