package com.syntax.class02;

public class Task2 {

	public static void main(String[] args) {

		double num = 3.9;

		System.out.println("The square of the " + num + " is " + (num * 4));

	}

}
