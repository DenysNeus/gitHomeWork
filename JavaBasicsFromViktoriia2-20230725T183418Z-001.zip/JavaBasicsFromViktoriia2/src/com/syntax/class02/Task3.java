package com.syntax.class02;

public class Task3 {

	public static void main(String[] args) {

		int width = 5;
		int height = 8;
		System.out.println("The perimeter of a rectangle with width " + width + " and height " + height
				+ " is equal to " + 2 * (width + height) + " and the area is " + (width * height));

	}

}
