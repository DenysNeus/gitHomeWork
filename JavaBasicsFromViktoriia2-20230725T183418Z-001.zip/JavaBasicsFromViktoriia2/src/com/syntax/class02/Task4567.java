package com.syntax.class02;

public class Task4567 {

	public static void main(String[] args) {

		int num = 37;
		num = num += 100;
		System.out.println(num);

		num = 576;
		num = num -= 67;
		System.out.println(num);

		double cakePiece = 11;
		cakePiece = cakePiece /= 4;
		System.out.println(cakePiece);

		cakePiece = 25;
		cakePiece = cakePiece /= 7;
		System.out.println(cakePiece);
		cakePiece = 25;
		cakePiece = cakePiece %= 7;
		System.out.println(cakePiece);
	}

}
