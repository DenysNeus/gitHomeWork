package com.syntax.class02;

public class Variables {

	public static void main(String[] args) {

		String name = "Adel";
		String lastName = "Smith";
		char grade = 'A';
		int age = 32;
		String city = "LA";
		String state = "Louisiana";
		String number = "+191764849028";
		System.out.println("Name " + name + " " + lastName + " age " + age + " City " + city + " State " + state
				+ " Phone number " + number + " Grade " + grade);
		city = "New York";
		state = "New York";
		number = "+56789046371";
		grade = 'C';
		System.out.println("Name " + name + " " + lastName + " age " + age + " City " + city + " State " + state
				+ " Phone number " + number + " Grade " + grade);

	}

}
