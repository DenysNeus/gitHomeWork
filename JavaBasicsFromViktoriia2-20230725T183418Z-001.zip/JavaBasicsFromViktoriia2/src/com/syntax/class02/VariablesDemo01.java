package com.syntax.class02;

public class VariablesDemo01 {

	public static void main(String[] args) {
		
		System.out.print("Class2 ");
		System.out.println(" First task");
byte hibyte=-127;
System.out.println(hibyte);
double hidouble=236.690;
System.out.println(hidouble);
	char a='V';
	System.out.println(a);
	boolean boo=true;
	boolean boo2=false;
	System.out.println(boo);
	System.out.println(boo2);
	
	
	String name="Denys";
	String adress="BayParkway";
	String phone="9178087142";
	System.out.println(name+" "+adress+" "+phone);
	
	}

}
