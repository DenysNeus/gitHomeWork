package com.syntax.class04;

public class IfNoBraces {

	public static void main(String[] args) {

		boolean sunny = false;
		if (sunny)
	    System.out.println("Today is sunny weather");
		System.out.println("I will go for a walk");
		System.out.println("I enjoy sun");
	}

}
