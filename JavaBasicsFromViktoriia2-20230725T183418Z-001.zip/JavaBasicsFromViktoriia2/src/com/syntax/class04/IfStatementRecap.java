package com.syntax.class04;

public class IfStatementRecap {

	public static void main(String[] args) {

		/*
		 * autocomplete:
		 * 
		 * syso+ctrl+space+enter main+ctrl+space+enter
		 */

		int day = 6;
		if (day == 6) {
			System.out.println("Today is Saturday");
			System.out.println("We are having Java");
		} else {
			System.out.println("Today is not Saturday");

		}
		System.out.println("***********************");
		if (day == 6)
			System.out.println("Today is Saturday ");
		else
			System.out.println("Today is not Saturday");
		System.out.println("Today is some other day");
		
		System.out.println("End of the code");
	}

}
