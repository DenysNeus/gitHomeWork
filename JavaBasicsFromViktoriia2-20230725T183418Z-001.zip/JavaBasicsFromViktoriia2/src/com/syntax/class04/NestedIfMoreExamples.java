package com.syntax.class04;

public class NestedIfMoreExamples {

	public static void main(String[] args) {

		boolean replCompleted = true;
		int assigments = 5;

		if (replCompleted) {
			//System.out.println("Great job!");
			if (assigments > 16) {
				System.out.println("You did an amazing job");
			} else if (assigments > 10) {
				System.out.println("You did good,but you should do more");
			} else if (assigments > 6) {
				System.out.println("You need to try do more homeworks");
			}

		} else {
			System.out.println("Please,make sure you do your homework");
		}
	}

}
