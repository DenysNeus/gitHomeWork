package com.syntax.class04;

import java.util.Scanner;

//short cut to import existing class to the current class
/*
 * mac:cmd+shift+o
 * windows: ctrl+shift+o
 */
public class ScannerDemo {

	public static void main(String[] args) {

		String str = "AbC";
		str = "xyZ";
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter your name");
		String name = scan.next();// it will capture String value from console
		System.out.println("Hello " + name);
		System.out.println("Please enter your name");

		int age = scan.nextInt();
		System.out.println(name + " you are " + age + " years old");
	}

}
