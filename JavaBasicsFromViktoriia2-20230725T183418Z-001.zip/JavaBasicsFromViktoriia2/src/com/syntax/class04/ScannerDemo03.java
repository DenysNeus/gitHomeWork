package com.syntax.class04;

import java.util.Scanner;

public class ScannerDemo03 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter the city");
		String city = scan.next();
		System.out.println("Please enter the temperature");
		double temp = scan.nextDouble();
		temp = (temp - 32) / 2;
		System.out.println("The temperature is the city " + city + " is " + temp);

	}

}
