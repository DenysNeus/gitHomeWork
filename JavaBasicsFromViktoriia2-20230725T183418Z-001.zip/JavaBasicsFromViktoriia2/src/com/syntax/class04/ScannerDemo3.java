package com.syntax.class04;

import java.util.Scanner;

public class ScannerDemo3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Please enter sentence");
		String line = in.nextLine();
		System.out.println(line);
	}

}
