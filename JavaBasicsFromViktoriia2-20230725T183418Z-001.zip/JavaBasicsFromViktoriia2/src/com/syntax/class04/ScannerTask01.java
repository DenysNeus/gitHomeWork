package com.syntax.class04;

import java.util.Scanner;

public class ScannerTask01 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Hi.What is amount of loan do you need?");
		double loan = scan.nextDouble();
		if (loan <= 200000) {
			System.out.println("We will lend you money");
		} else {
			System.out.println("Sorry, we have to reject your request");
		}

	}

}
