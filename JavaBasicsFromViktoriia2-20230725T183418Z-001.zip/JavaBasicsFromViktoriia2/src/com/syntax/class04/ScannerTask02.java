package com.syntax.class04;

import java.util.Scanner;

public class ScannerTask02 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Hi. Please enter your name");
		int age = scan.nextInt();
		if (age >= 18) {
			System.out.println("Congratulations! Here are your driver license");
		} else {
			System.out.println("You need to get a learners permit ");
		}
	}
}
