package com.syntax.class04;

import java.util.Scanner;

public class ScannerTask04 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Hi.Do you have a credit card?");
		boolean card = scan.nextBoolean();

		if (card) {
			System.out.println("What is balance on your card?");
			double balance = scan.nextDouble();
			if (balance > 1000) {
				System.out.println("Pay off immediately");
			} else {
				System.out.println("You can spend more money");
			}

		} else {
			System.out.println("Do you want a credit card?");
		}
	}

}
