package com.syntax.class04;

import java.util.Scanner;

public class ScannerTask05 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter number of your worked years");
		double years = scan.nextDouble();
		if (years >= 5) {
			System.out.println("You are eligible for the bonus");
			System.out.println("What salary do you have?");
			double salary = scan.nextDouble();
			if (salary > 5000) {
				System.out.println("your bonus = 5000");
			} else {
				System.out.println("Your bonus =3000");
			}
		} else {
			System.out.println("Sorry,you don`t have a bonus");
		}
	}

}
