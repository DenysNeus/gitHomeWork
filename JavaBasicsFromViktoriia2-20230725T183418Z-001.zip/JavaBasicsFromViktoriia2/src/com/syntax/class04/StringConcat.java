package com.syntax.class04;

public class StringConcat {

	public static void main(String[] args) {
		String num = "10";
		int num1 = 10;
		double num2 = 10;
		System.out.println(num + num1 + num2);
		System.out.println(num1 + num + num2);
		System.out.println(num1 + num2 + num);
	}

}
