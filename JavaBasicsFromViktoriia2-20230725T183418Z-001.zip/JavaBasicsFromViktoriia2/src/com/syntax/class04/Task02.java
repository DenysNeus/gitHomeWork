package com.syntax.class04;

public class Task02 {

	public static void main(String[] args) {

		double rate = 4.5;
		double price = 200000;
		if (rate <= 4.5) {
			System.out.println("I will by a house!");
			if (price >= 200000) {
				System.out.println("I will take a loan");
			} else {
				System.out.println("I will pay cash");
			}

		} else {
			System.out.println("I will not by a house!");
		}
	}

}
