package com.syntax.class04;

public class Task03 {

	public static void main(String[] args) {

		int age = 18;
		double weight = 110;
		if (age >= 18) {
			System.out.println("Great!Now we will check your waight");
			if (weight >= 110) {
				System.out.println("Your weight is good,you are eligible to donate");
			} else {
				System.out.println("Sorry,we can not accept you");
			}

		} else {
			System.out.println("Sorry, you are not eligible to donate your blood");
		}

	}

}
