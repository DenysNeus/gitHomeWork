package com.syntax.class04;

public class Task04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
