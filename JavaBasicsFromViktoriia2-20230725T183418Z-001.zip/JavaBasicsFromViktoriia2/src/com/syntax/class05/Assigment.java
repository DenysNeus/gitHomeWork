package com.syntax.class05;

import java.util.Scanner;

public class Assigment {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter current time");
		int time = scan.nextInt();
		if (time >= 1 && time <= 11) {
			System.out.println("Right now is morning");
		} else if (time >= 12 && time <= 15) {
			System.out.println("Right now is afternoon");
		} else if (time >= 16 && time <= 20) {
			System.out.println("Right now is evening");
		} else if (time >= 21 && time <= 24) {
			System.out.println("Right now is night");
		} else {
			System.out.println("Not valid time entered");
		}
		
		
		System.out.println("----------------------------");
		String timeOfDay=null;
		if (time >= 1 && time <= 11) {
			timeOfDay = "morning";
		} else if (time >= 12 && time <= 15) {
			timeOfDay = "afternoon";
		} else if (time >= 16 && time <= 20) {
			timeOfDay = "evening";
		} else if (time >= 21 && time <= 24) {
			timeOfDay = "night";
		} else {
			timeOfDay = "Invalid";
		}
		System.out.println("Right now is " + timeOfDay);
	}

}
