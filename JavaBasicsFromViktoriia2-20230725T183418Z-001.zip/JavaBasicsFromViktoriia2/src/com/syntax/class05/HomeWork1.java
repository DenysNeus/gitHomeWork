package com.syntax.class05;

import java.util.Scanner;

public class HomeWork1 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter your birth month");
		String month = scan.next();
		String season=null;
		if (month.equalsIgnoreCase("desember") || month.equalsIgnoreCase("january")
				|| month.equalsIgnoreCase("february")) {
			season = "Winter";

		} else if (month.equalsIgnoreCase("march") || month.equalsIgnoreCase("april")
				|| month.equalsIgnoreCase("may")) {
			season = "Spring";
		} else if (month.equalsIgnoreCase("june") || month.equalsIgnoreCase("july")
				|| month.equalsIgnoreCase("august")) {
			season = "Summer";
		} else if (month.equalsIgnoreCase("september") || month.equalsIgnoreCase("october")
				|| month.equalsIgnoreCase("november")) {
			season = "Fall";
		}
		if (season!=null) {
	System.out.println("You were born is season "+season);
		}
		}
}
