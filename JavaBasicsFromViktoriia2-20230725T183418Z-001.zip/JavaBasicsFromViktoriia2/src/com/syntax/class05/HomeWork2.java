package com.syntax.class05;

import java.util.Scanner;

public class HomeWork2 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter your quiz,mid term and final score");
		int quize = scan.nextInt();
		int midTerm = scan.nextInt();
		int finalScore = scan.nextInt();
		String grade=null;
		if ((quize + midTerm + finalScore) >= 90) {
			grade = "A";
		} else if ((quize + midTerm + finalScore) >= 70 && (quize + midTerm + finalScore) < 90) {
			grade = "B";
		} else if ((quize + midTerm + finalScore) >= 50 && (quize + midTerm + finalScore) < 70) {
			grade = "C";
		} else if ((quize + midTerm + finalScore) <= 50) {
			grade = "F";
		}
System.out.println("Your grade is "+grade);
	}

}
