package com.syntax.class05;

import java.util.Scanner;

public class LargestNumber {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter 3 numbers");
		double num = scan.nextDouble();
		double num1 = scan.nextDouble();
		double num2 = scan.nextDouble();
		if (num == num1 && num1 == num2) {
			System.out.println("Numbers are equal");
		}else {
			if (num >= num1 && num > num2) {
				System.out.println(num + " is the largest number");
			} else if (num1 >= num && num1 > num2) {
				System.out.println(num1 + " is the largest number");
			} else if (num2 > num && num2 >= num1) {
				System.out.println(num2 + " is the largest number");
			}
		}
		
		}

	}
