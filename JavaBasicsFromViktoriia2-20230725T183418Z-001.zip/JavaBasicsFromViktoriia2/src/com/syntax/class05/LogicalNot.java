package com.syntax.class05;

public class LogicalNot {

	public static void main(String[] args) {

		boolean boo = !true;
		System.out.println(boo);

		boolean abc = !false;
		System.out.println(abc);

		boolean isRain = false;
		if (!isRain) {
			System.out.println("I will go for a walk");

		} else {
			System.out.println("I will stay at home");
		}
		String username = "Test";
		String password = "Test";
		if (!username.equals(password)) {
			System.out.println("I am accepting your pasword");

		}
		boolean selected = false;
		if (!selected) {
			System.out.println("do click");
		}

	}

}
