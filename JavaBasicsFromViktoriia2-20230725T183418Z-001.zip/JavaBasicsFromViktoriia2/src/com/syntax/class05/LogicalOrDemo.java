package com.syntax.class05;

import java.util.Scanner;

public class LogicalOrDemo {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter today`s day");
		String day = scan.next();
		if ((day.equalsIgnoreCase("monday")) || (day.equalsIgnoreCase("friday"))) {
			System.out.println("Today is no class");
		} else if ((day.equalsIgnoreCase("tuesday")) || (day.equalsIgnoreCase("wednesday"))) {
			System.out.println("Today is manual class");
		} else if ((day.equalsIgnoreCase("saturday")) || (day.equalsIgnoreCase("sunday"))) {
			System.out.println("Today is java class");
		} else {
			System.out.println("Wrong input");
		}
	}

}
