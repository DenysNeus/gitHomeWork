package com.syntax.class06;

public class SwitchDemo {

	static void main(String[] args) {

		char gender = 'H';
		String description;

		switch (gender) {
		case 'm':
			description = "Male";
			break;
		case 'M':
			description = "Male";
			break;
		case 'f':
			description = "Female";
			break;
		case 'F':
			description = "Female";
			break;
		default:
			description = "Unknown";
		}
		System.out.println(gender + " means " + description);
	}

}
