package com.syntax.class06;

import java.util.Scanner;

public class SwitchDemo2 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter country");
		String country = scan.next();
		String food;

		switch (country.toLowerCase()) {
		case "spain":
			food = "Paella";
			break;
		case "india":
			food = "Butter Chicken";
			break;
		case "thai":
			food = "Pad Thai";
			break;
		case "japan":
			food = "Sushi";
			break;
		case "korea":
			food = "Bibimbap";
			break;
		default:
			food = "Unknow";
		}
		if (!food.equals("Unknow")) {

			System.out.println("In " + country + " traditional food is " + food);
		} else {
			System.out.println("Try another country");
		}
	}

}
