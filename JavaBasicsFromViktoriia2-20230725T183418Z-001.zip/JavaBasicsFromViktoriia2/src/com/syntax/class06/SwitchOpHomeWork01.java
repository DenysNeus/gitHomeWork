package com.syntax.class06;

import java.util.Scanner;

public class SwitchOpHomeWork01 {

	public static void main(String[] args) {

		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter two any numbers");
		double num1=scan.nextDouble();
		double num2=scan.nextDouble();
	System.out.println("Please enter any operator");
	char opr=scan.next().charAt(0);
	
	
	
	}
	

}
