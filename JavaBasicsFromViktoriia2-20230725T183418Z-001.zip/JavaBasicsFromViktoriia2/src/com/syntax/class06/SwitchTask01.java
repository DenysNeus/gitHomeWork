package com.syntax.class06;

import java.util.Scanner;

public class SwitchTask01 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter country");
		String country = scan.next();
		String language;

		switch (country.toLowerCase()) {
		case "austria":
			language = "german";
			break;
		case "cameroon":
			language = "french";
			break;
		case "indonesia":
			language = "indonesian";
			break;
		case "nepal":
			language = "nepali";
			break;
		case "vietnam":
			language = "vietnamese";
			break;
		default:
			language = "Unknow";
		break;
		}	
		if (!language.equals("Unknow")) {
				System.out.println("In " + country + " official language is " + language);
			} else {
				System.out.println("Try another country");
			}

		

	}

}
