package com.syntax.class06;

import java.util.Scanner;

public class SwitchTask02 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter your grade");

		// char grade=scan.next().charAt(0);

		String grade = scan.next();
		String expl;

		switch (grade.toUpperCase()) {
		case "A":
			expl = "Excellent";
			break;
		case "B":
			expl = "Good";
			break;
		case "C":
			expl = "Average";
			break;
		case "D":
			expl = "Bad";
			break;
		default:
			expl = "Unknown";
			break;
		}
		if (!expl.equals("Unknown")) {
			System.out.println(grade + "-" + expl);

		} else {
			System.out.println("Try another output");
		}

	}
}
