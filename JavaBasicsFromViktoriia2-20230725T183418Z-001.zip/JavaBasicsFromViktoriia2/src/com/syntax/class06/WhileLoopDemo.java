package com.syntax.class06;

public class WhileLoopDemo {

	public static void main(String[] args) {
		System.out.println("Print EVEN numbers from 1 to 10");

		int num = 2;
		while (num <= 10) {
			System.out.print(num + " ");
			num += 2;
		}
		System.out.println();
		System.out.println("I am outside of the loop");
		System.out.println(num);

		System.out.println("--------Another Way---------");

		int a = 1;
		while (a <= 10) {
			if (a % 2 == 0) {
				System.out.print(a + " ");
			}
			a++;
		}
		System.out.println();

	}

}
