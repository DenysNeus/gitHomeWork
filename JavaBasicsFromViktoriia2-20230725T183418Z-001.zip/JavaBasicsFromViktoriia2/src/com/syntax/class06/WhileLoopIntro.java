package com.syntax.class06;

public class WhileLoopIntro {

	public static void main(String[] args) {

		int time = 14;
		while (time < 17) {
			System.out.println("It is a day");
			time++;
		}
		System.out.println("Print numbers from 1 to 20");
		int num = 1;
		while (num <= 20) {
			System.out.print(num + " ");
			num++;
		}
		System.out.println();
System.out.println("---------------------");
	
	System.out.println("Print numbers from 50 to 1");
	
	int num1=50;
	while(num1>=1) {
		System.out.print(num1+" ");
	num1--;
	}
	System.out.println();
	System.out.println("--------------------------");
	
	}

	
}
