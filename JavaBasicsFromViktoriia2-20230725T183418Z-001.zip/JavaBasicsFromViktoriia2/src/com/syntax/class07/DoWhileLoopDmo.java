package com.syntax.class07;

public class DoWhileLoopDmo {

	public static void main(String[] args) {

		int a = 1;

		while (a >= 3) {
			System.out.println("Hi");
			a++;
		}

		System.out.println("   CODE USING DO WHILE LOOP    ");
		int b = 1;
		do {
			System.out.println("Hello");
			b++;
		} while (b <= 3);

	}

}
