package com.syntax.class07;

public class DoWhileLoopTasks {

	public static void main(String[] args) {
/*
 * print number from 30 to 70 using do while loop
 * 
 * print odd numbers from 99 to 1 using do while loop
 * 
 */
	
	int num=30;
	do {
		System.out.print(num+" ");
	num++;
	}while(num<=70);
	
	
	
	int num1=99;
	do {
	System.out.print(num1+" ");	
	num1++;	
		
	}while(num1>=1);
	if(num1%2!=0) {
		System.out.println(num1+" ");
	}
	
	}

}
