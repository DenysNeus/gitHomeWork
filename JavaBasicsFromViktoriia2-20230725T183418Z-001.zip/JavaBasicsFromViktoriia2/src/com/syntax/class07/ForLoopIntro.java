package com.syntax.class07;

public class ForLoopIntro {

	public static void main(String[] args) {
		/*
		 * 1.initialization 2.condition 3.increment/dicrement
		 */

		for (int i = 1; i <= 5; i++) {
			System.out.println("Hello");
		}

		System.out.println("______Print numbers from 1 to 20_______");
		/*
		 * 1.start point 2.end point 3.increment/decrement
		 */
		for (int a = 1; a <= 20; a++) {
			System.out.print(a + " ");
		}
		System.out.println();
		System.out.println("-------- print numbers from 100 to 20--------");

		for (int b = 100; b >= 20; b--) {
			System.out.print(b + " ");
		}
		System.out.println();
		System.out.println("****** Print EVEN  numbers from 1 to 50 *******");

		for (int i = 1; i <= 50; i++) {

			if (i % 2 == 0) {
				System.out.print(i + " ");
			}
			
		}
		System.out.println();
				System.out.println("****** Print EVEN  numbers from 1 to 50 *******");

			for (int i=2; i<50; i+=2) {
				System.out.print(i+" ");
			}
			System.out.println();
			System.out.println("****** What will be the output? *******");

		for(int i=1; i<=40; i+=5) {
			System.out.print(i+" ");
		}
	}

}
