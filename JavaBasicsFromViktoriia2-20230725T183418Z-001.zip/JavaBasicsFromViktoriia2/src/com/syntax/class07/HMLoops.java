package com.syntax.class07;

public class HMLoops {

	public static void main(String[] args) {

		int c = 20;
		while (c <= 100) {
			if (c % 2 == 0) {
				System.out.print(c + " ");
			}
			c++;
		}

	int a=1;
	
	while(a<=100) {
		System.out.print(a+" ");
	}
	a++;
	}
	
	

}
