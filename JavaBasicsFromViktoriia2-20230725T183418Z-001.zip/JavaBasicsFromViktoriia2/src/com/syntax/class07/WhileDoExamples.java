package com.syntax.class07;

public class WhileDoExamples {

	public static void main(String[] args) {

		int num1 = 99;
		do {
			System.out.print(num1 + " ");
			
			if (num1 % 2 != 0) {
				System.out.print(num1 + " ");
			}
		} while (num1 >= 1);

	}

}
