package com.syntax.class3;

public class HomeWork1 {

	public static void main(String[] args) {

		double num = 456.936;
		double num1 = 532.87;
		if (num >= num1) {
			System.out.println("Double variable 456.936 is larger than 532.87");
		} else {
		}
		System.out.println("Double variable 532.87 is larger than 456.936");

	}

}
