package com.syntax.class3;

public class HomeWork2 {

	public static void main(String[] args) {

		double temp = 67;
		if (temp < 32) {
			System.out.println("Water will freeze with temperature " + temp);
		} else {
			System.out.println("Water will NOT freeze with temperature " + temp);
		}
	}

}
