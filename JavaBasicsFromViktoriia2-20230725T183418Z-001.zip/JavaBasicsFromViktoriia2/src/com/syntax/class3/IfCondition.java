package com.syntax.class3;

public class IfCondition {

	public static void main(String[] args) {

		int num = 10;
		int num1 = 36;
		System.out.println("Before if condition");
		if (true) {
			System.out.println("I am inside if condition");
		}
		System.out.println("After if condition");
	}

}
