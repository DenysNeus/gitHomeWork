package com.syntax.class3;

public class IfConditionDemo1 {

	public static void main(String[] args) {
		int number = 60;

		if (number >= 60) {
			System.out.println("I am will be successful in testing");
		} else {

			System.out.println("I will be successful in photo");
		}
		
		String name ="Gita";
		String pasword="12345";
		if(name.equals("Gita")) {
		System.out.println("Hi Gita");	
		}else {
			System.out.println("I do not know you");
		}
		
		
		
		
		
	}
	
	
	

}
