package com.syntax.class3;

public class IfConditionDemo2 {

	public static void main(String[] args) {

		double actualHours=20;
		double expectedHourse=15;
		if(actualHours<expectedHourse) {
			System.out.println("Course will be hard for you");
		}else {
			System.out.println("Course is easy,you will getyour job after 5 months");
		}
	
	
	
	
	
	}
	
	

}
