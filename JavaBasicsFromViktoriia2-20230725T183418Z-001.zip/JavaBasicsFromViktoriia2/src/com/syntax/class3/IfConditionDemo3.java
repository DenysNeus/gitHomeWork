package com.syntax.class3;

public class IfConditionDemo3 {

	public static void main(String[] args) {

		double chocolatePrice = 4.89;
		double moneyIHave = 4.89;
		if (moneyIHave >= chocolatePrice) {
			System.out.println("I am happy:) I have my chocolate");
		} else {
			System.out.println("I am sad,i don`t have enough money");
		}

	}

}
