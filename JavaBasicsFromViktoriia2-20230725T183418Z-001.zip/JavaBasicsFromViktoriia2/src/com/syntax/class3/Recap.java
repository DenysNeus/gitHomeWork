package com.syntax.class3;

public class Recap {

	public static void main(String[] args) {
String var1="Hello World";
int num1=10;
String result=var1+num1;
System.out.println(result);
	boolean isTrue=true;
	System.out.println(isTrue+result);
	System.out.println("************************");
	
	int num=10;
	int num2=3;
System.out.println(num/num2);
System.out.println(num%num2);
System.out.println("****************");
 double number=10;
 number++;
 System.out.println(number);
 System.out.println("*******************");
 int number1=100;
 number1*=4;
 System.out.println(number1);
 
 

		
	}

}
