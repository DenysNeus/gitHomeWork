package com.syntax.class3;

public class RelationOperator {

	public static void main(String[] args) {
		int box = 27;
		int box1 = 27;
		System.out.println(box == box1);// checks if both variables contain same thing

		int num = 34;
		int num1 = 46;
		boolean result = num == num1;
		System.out.println(result);

		System.out.println("*********************");

		System.out.println(num > num1);
		System.out.println(num < num1);
		System.out.println("*********************");

		System.out.println(num >= num1);
		System.out.println(num <= num1);
		
		System.out.println("*********************");
		System.out.println(num!=num1);
		
	}

}
