package com.syntax.class3;

public class Task1 {

	public static void main(String[] args) {

		double num1 = 465;
		double num2 = 334;
		double one = num1 + num2;
		double two = num1 - num2;
		double three = num2 * num2;
		double four = num1 / num2;

		System.out.println("The add of two numbers " + num1 + " and " + num2 + " is equal to " + one);
		System.out.println("The subtract of two numbers " + num1 + " and " + num2 + " is equal to " + two);
		System.out.println("The multiply of two numbers " + num1 + " and " + num2 + " is equal to " + three);
		System.out.println("The divide of two numbers " + num1 + " and " + num2 + " is equal to " + four);
	}

}
