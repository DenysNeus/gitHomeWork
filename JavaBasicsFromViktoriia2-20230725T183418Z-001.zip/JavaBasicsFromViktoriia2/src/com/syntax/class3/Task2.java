package com.syntax.class3;

public class Task2 {

	public static void main(String[] args) {

		double num = 83.9;
		double square = num * num;
		System.out.println("The square of the " + num + " is " + square);

	}

}
