package com.syntax.class3;

public class Task3 {

	public static void main(String[] args) {

		double num = 5;
		double num1 = 8;
		double area = num * num1;
		double perimeter = 2 * (num + num1);
		System.out.println("The perimeter of a rectangle with width " + num + " and height " + num1 + " is equal to "
				+ perimeter + " and the area is " + area);

	}

}
