package com.syntax.class3;

public class Task4 {

	public static void main(String[] args) {

		int num = 100;
		num += 100;
		System.out.println(num);

		int num1 = 100;
		num1 -= 67;
		System.out.println(num1);

		int cakePiece = 11;
		cakePiece /= 4;
		System.out.println(cakePiece);

		int cakePiece1 = 25;
		cakePiece1 /= 7;
		System.out.println(cakePiece1);
		cakePiece1 = 25;
		System.out.println(cakePiece1 %= 7);

	}

}
