package com.syntax.class3;

public class TypeCasting {

	public static void main(String[] args) {

		int num = 10; // define
		double num1;// define
		num1 = num; // assigning
		System.out.println(num1);

		double num2 = 10;
		int num3;
		num3 = (int) num2;
		System.out.println(num3);

		int number = 1256;
		byte number1 = (byte) number;// does not work!!!!
		System.out.println(number1);

		short number2 = 12;
		byte number3 = (byte) number2;
		System.out.println(number3);

		int number4 = 1000;
		float f = number4;
		long l = (long) f;
		System.out.println(l);

		double number5 = 10.5;
		int number6 = (int) number5;
		System.out.println(number6);

	}

}
